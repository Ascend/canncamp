#!/bin/bash
# Copyright 2019-2020 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

set -e
export BASE_PATH=$(cd "$(dirname $0)"; pwd)
export BUILD_PATH="${BASE_PATH}/build"
RELEASE_PATH="${BASE_PATH}/output"
INSTALL_PATH="${BUILD_PATH}/install"
CMAKE_HOST_PATH="${BUILD_PATH}/cann"
CMAKE_DEVICE_PATH="${BUILD_PATH}/cann_device"

source scripts/util/util.sh

# print usage message
usage() {
  echo "Usage:"
  echo "    bash build.sh [-h] [-j[n]] [-u] [-s] [-v] [-g]"
  echo ""
  echo "Options:"
  echo "    -h Print usage"
  echo "    -j[n] Set the number of threads used to build CANN, default is 8"
  echo "    -u Build UT"
  echo "    -s Build ST"
  echo "    -v Verbose"
  echo "    -g GCC compiler prefix, used to specify the compiler toolchain"
  echo "    -a|--aicpu only compile aicpu task"
  echo "    -m|--minirc aicpu only compile aicpu task"

  echo "to be continued ..."
}

# parse and set optionss
checkopts() {
  VERBOSE=""
  THREAD_NUM=8
  GCC_PREFIX=""
  UT_TEST=FALSE
  ST_TEST=FALSE
  AICPU_ONLY=FALSE
  MINIRC_AICPU_ONLY=FALSE
  # Process the options
  while getopts 'hj:usvg:a-:m-:' opt
  do
    case "${opt}" in
      h) usage
         exit 0 ;;
      j) THREAD_NUM=$OPTARG ;;
      u) UT_TEST=TRUE ;;
      s) ST_TEST=TRUE ;;
      v) VERBOSE="VERBOSE=1" ;;
      g) GCC_PREFIX=$OPTARG ;;
      a) AICPU_ONLY=TRUE ;;
      m) MINIRC_AICPU_ONLY=TRUE ;;
      -) case $OPTARG in
           aicpu) AICPU_ONLY=TRUE ;;
           minirc) MINIRC_AICPU_ONLY=TRUE ;;
           *) logging "Undefined option: $OPTARG"
              usage
              exit 1 ;;
         esac
         ;;
      *) logging "Undefined option: ${opt}"
         usage
         exit 1 ;;
    esac
  done
}

# create build path
build_cann() {
  logging "Create build directory and build CANN"
  CMAKE_ARGS="-DBUILD_PATH=$BUILD_PATH -DBUILD_OPEN_PROJECT=TRUE"
  if [[ "$GCC_PREFIX" != "" ]]; then
    CMAKE_ARGS="$CMAKE_ARGS -DGCC_PREFIX=$GCC_PREFIX"
  fi
  if [[ "$UT_TEST" == "TRUE" ]]; then
    CMAKE_ARGS="$CMAKE_ARGS -DUT_TEST=TRUE"
  else
    CMAKE_ARGS="$CMAKE_ARGS -DUT_TEST=FALSE"
  fi
  if [[ "$ST_TEST" == "TRUE" ]]; then
    CMAKE_ARGS="$CMAKE_ARGS -DST_TEST=TRUE"
  else
    CMAKE_ARGS="$CMAKE_ARGS -DST_TEST=FALSE"
  fi
  if [[ "$AICPU_ONLY" == "TRUE" ]]; then
    CMAKE_ARGS="$CMAKE_ARGS -DAICPU_ONLY=TRUE"
  else
    CMAKE_ARGS="$CMAKE_ARGS -DAICPU_ONLY=FALSE"
  fi
  logging "Start build host target. CMake Args: ${CMAKE_ARGS}"

  if [[ "$ST_TEST" == "FALSE" ]]; then
    mk_dir "${CMAKE_HOST_PATH}"
    cd "${CMAKE_HOST_PATH}" && cmake ${CMAKE_ARGS} ../..
    make ${VERBOSE} -j${THREAD_NUM}
  fi
  if [[ "$UT_TEST" == "FALSE" ]]; then
    CMAKE_ARGS="-DBUILD_PATH=$BUILD_PATH -DBUILD_OPEN_PROJECT=TRUE -DPRODUCT_SIDE=device"

    logging "Start build device target. CMake Args: ${CMAKE_ARGS}"
    mk_dir "${CMAKE_DEVICE_PATH}"
    cd "${CMAKE_DEVICE_PATH}" && cmake ${CMAKE_ARGS} ../..
    make ${VERBOSE} -j${THREAD_NUM}
  fi

  logging "CANN build success!"
}

minirc(){
  CMAKE_ARGS="-DBUILD_PATH=$BUILD_PATH -DBUILD_OPEN_PROJECT=TRUE -DPRODUCT_SIDE=device -DMINRC=TRUE"
  logging "Start build device target. CMake Args: ${CMAKE_ARGS}"
  mk_dir "${CMAKE_DEVICE_PATH}"
  cd "${CMAKE_DEVICE_PATH}" && cmake ${CMAKE_ARGS} ../..
  make ${VERBOSE} -j${THREAD_NUM}

}
release_cann() {
  logging "Create output directory"
  mk_dir "${RELEASE_PATH}"
  RELEASE_TARGET="cann.tar"
  if [ "$MINIRC_AICPU_ONLY" = "TRUE" ];then
     RELEASE_TARGET="aicpu_minirc.tar"
  fi
  cd ${INSTALL_PATH} && tar cfz "${RELEASE_TARGET}" * && mv "${RELEASE_TARGET}" "${RELEASE_PATH}"
}

main() {
  checkopts "$@"
  # CANN build start
  logging "---------------- CANN build start ----------------"
  if [ "$MINIRC_AICPU_ONLY" = "TRUE" ]; then
    ${GCC_PREFIX}g++ -v
    minirc 
  else
    ${GCC_PREFIX}g++ -v
    build_cann
  fi
  release_cann
  logging "---------------- CANN build finished ----------------"
}

main "$@"
