#!/usr/bin/python
# -*- coding: UTF-8 -*-
#这个文件的作用是：
#包含这个文件，python ut工程就认为这个目录是python ut用例的目录，会自动包含这个目录下的所有用例，否则这个目录下的用例不会被执行