#!/usr/bin/env python
# -*- coding: UTF-8 -*-

class LLTConf:
    default_dynamic_case_cnt = 10

    op_cfg_file_path = {}

    op_select_format_name = "op_select_format"

    check_support_func_name = "check_supported"
