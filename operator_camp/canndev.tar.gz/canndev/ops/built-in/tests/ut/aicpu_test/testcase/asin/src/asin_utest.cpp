/**
 * Copyright 2021 Jilin University
 * Copyright 2020 Huawei Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "gtest/gtest.h"
#include "aicpu_test_utils.h"
#include "cpu_kernel_utils.h"
#include "node_def_builder.h"
#include "aicpu_read_file.h"
#include "Eigen/Core"

class TEST_ASIN_UT : public testing::Test {};

template <typename T>
inline aicpu::DataType to_data_type() {
  return aicpu::DataType::DT_UNDEFINED;
}
template <>
inline aicpu::DataType to_data_type<Eigen::half>() {
  return aicpu::DataType::DT_FLOAT16;
}
template <>
inline aicpu::DataType to_data_type<std::float_t>() {
  return aicpu::DataType::DT_FLOAT;
}
template <>
inline aicpu::DataType to_data_type<std::double_t>() {
  return aicpu::DataType::DT_DOUBLE;
}
template <>
inline aicpu::DataType to_data_type<std::int8_t>() {
  return aicpu::DataType::DT_INT8;
}
template <>
inline aicpu::DataType to_data_type<std::int16_t>() {
  return aicpu::DataType::DT_INT16;
}
template <>
inline aicpu::DataType to_data_type<std::int32_t>() {
  return aicpu::DataType::DT_INT32;
}
template <>
inline aicpu::DataType to_data_type<std::int64_t>() {
  return aicpu::DataType::DT_INT64;
}
template <>
inline aicpu::DataType to_data_type<std::uint8_t>() {
  return aicpu::DataType::DT_UINT8;
}
template <>
inline aicpu::DataType to_data_type<std::uint16_t>() {
  return aicpu::DataType::DT_UINT16;
}
template <>
inline aicpu::DataType to_data_type<std::uint32_t>() {
  return aicpu::DataType::DT_UINT32;
}
template <>
inline aicpu::DataType to_data_type<std::uint64_t>() {
  return aicpu::DataType::DT_UINT64;
}
template <typename T>
inline const char* to_data_name() {
  return typeid(T).name();
}
template <>
inline const char* to_data_name<Eigen::half>() {
  return "float16";
}
template <>
inline const char* to_data_name<std::float_t>() {
  return "float32";
}
template <>
inline const char* to_data_name<std::double_t>() {
  return "float64";
}
template <>
inline const char* to_data_name<std::int8_t>() {
  return "int8";
}
template <>
inline const char* to_data_name<std::int16_t>() {
  return "int16";
}
template <>
inline const char* to_data_name<std::int32_t>() {
  return "int32";
}
template <>
inline const char* to_data_name<std::int64_t>() {
  return "int64";
}
template <>
inline const char* to_data_name<std::uint8_t>() {
  return "uint8";
}
template <>
inline const char* to_data_name<std::uint16_t>() {
  return "uint16";
}
template <>
inline const char* to_data_name<std::uint32_t>() {
  return "uint32";
}
template <>
inline const char* to_data_name<std::uint64_t>() {
  return "uint64";
}
inline std::uint64_t size_of(std::vector<std::int64_t>& shape) {
  return std::accumulate(shape.begin(), shape.end(), 1, std::multiplies<int>());
}
inline void run_kernel_Asin(std::shared_ptr<aicpu::NodeDef> node_def, aicpu::DeviceType device_type, uint32_t expect) {
  std::string node_def_str;
  node_def->SerializeToString(node_def_str);
  aicpu::CpuKernelContext ctx(device_type);
  EXPECT_EQ(ctx.Init(node_def.get()), aicpu::KernelStatus::KERNEL_STATUS_OK);
  uint32_t ret = aicpu::CpuKernelRegister::Instance().RunCpuKernel(ctx);
  EXPECT_EQ(ret, expect);
}
template <>
bool CompareResult(Eigen::half output[], Eigen::half expect_output[], uint64_t num) {
  uint64_t count{0};
  for (uint64_t i = 0; i < num; ++i) {
    if (output[i] != expect_output[i]) {
      std::cout << "output[" << i << "] = ";
      std::cout << output[i];
      std::cout << ", expect_output[" << i << "] = ";
      std::cout << expect_output[i] << std::endl;
      ++count;
    }
  }
  return count <= num / 1000;
}
template <typename T>
void RunTest() {
  auto data_type{to_data_type<T>()};
  auto data_name{to_data_name<T>()};
  EXPECT_NE(data_type, aicpu::DataType::DT_UNDEFINED);

  std::uint64_t dim[1];
  std::string data_dim_path = ktestcaseFilePath + "asin/data/asin_data_" + data_name + "_dim.txt";
  EXPECT_EQ(ReadFile(data_dim_path, dim, 1), true);

  std::uint64_t shape[dim[0]];
  std::string data_shape_path = ktestcaseFilePath + "asin/data/asin_data_" + data_name + "_shape.txt";
  EXPECT_EQ(ReadFile(data_shape_path, shape, dim[0]), true);

  std::vector<std::int64_t> dims(shape, shape + dim[0]);
  auto input1_size = size_of(dims);

  T data1[input1_size];
  std::string data_path = ktestcaseFilePath + "asin/data/asin_data_input_" + data_name + ".txt";
  EXPECT_EQ(ReadFile(data_path, data1, input1_size), true);

  T output[input1_size];
  auto node_def{aicpu::CpuKernelUtils::CreateNodeDef()};
  aicpu::NodeDefBuilder(node_def.get(), "Asin", "Asin")
      .Input({"x", data_type, dims, data1})
      .Output({"y", data_type, dims, output});
  run_kernel_Asin(node_def, aicpu::DeviceType::HOST, aicpu::KernelStatus::KERNEL_STATUS_OK);

  T expect_out[input1_size];
  std::string out_data_path = ktestcaseFilePath + "asin/data/asin_data_output_" + data_name + ".txt";
  EXPECT_EQ(ReadFile(out_data_path, expect_out, input1_size), true);
  EXPECT_EQ(CompareResult(output, expect_out, input1_size), true);
}

#define ADD_CASE(base_type, aicpu_type)          \
  TEST_F(TEST_ASIN_UT, DATA_TYPE_##aicpu_type) { \
    RunTest<base_type>();                        \
  }

ADD_CASE(Eigen::half, DT_FLOAT16)
ADD_CASE(std::float_t, DT_FLOAT)
ADD_CASE(std::double_t, DT_DOUBLE)
