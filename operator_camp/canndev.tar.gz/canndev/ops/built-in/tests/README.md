## run ut step

1. config set_env.sh
2. source set_env.sh
3. python3.7 run_ut.py --soc_version=Ascend910
