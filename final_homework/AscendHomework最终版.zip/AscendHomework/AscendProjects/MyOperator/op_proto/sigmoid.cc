#include "sigmoid.h"
namespace ge {

IMPLEMT_COMMON_INFERFUNC(SigmoidInferShape)
{
    return GRAPH_SUCCESS;
}

IMPLEMT_VERIFIER(Sigmoid, SigmoidVerify)
{
    return GRAPH_SUCCESS;
}

COMMON_INFER_FUNC_REG(Sigmoid, SigmoidInferShape);
VERIFY_FUNC_REG(Sigmoid, SigmoidVerify);

}  // namespace ge
