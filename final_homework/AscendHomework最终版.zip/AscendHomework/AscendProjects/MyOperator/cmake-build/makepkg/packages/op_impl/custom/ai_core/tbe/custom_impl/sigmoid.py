import tbe.dsl as tbe
from tbe import tvm
from tbe.common.register import register_op_compute
from tbe.common.utils import para_check
from tbe.common.utils import shape_util
from functools import reduce


# pylint: disable=locally-disabled,unused-argument,invalid-name
@register_op_compute("sigmoid", op_mode="static", support_fusion=False)
def sigmoid_compute(x, y,  kernel_name="sigmoid"):
    print("=================当老谭看到这句话时，说明我的自定义sigmoid算子被执行了============================")

    inp_dtype = x.dtype.lower()
    shape = x.shape

    if inp_dtype in  ("float16","float32"):
        # 算 e^x
        data = tvm.placeholder(shape, name="data", dtype=inp_dtype)
        res = tbe.dsl.vexp(data)

        # shape_res = res.share

        # 算 1+e^x
        const_val = tvm.const(1, "float32")
        shape_add = tbe.dsl.vadd(const_val, res)


        # 算除法
        data_res = tbe.dsl.vdiv(res, shape_add)


        # data1 = tvm.placeholder(shape, name="data1", dtype=input_dtype)
        # data2 = tvm.placeholder(shape, name="data1", dtype=input_dtype)
        # res = tbe.dsl.vadd(data1, data2)

        data_res = tbe.cast_to(data_res, inp_dtype)
    print("=================sigmoid_compute已调用=================")
    return data_res



@para_check.check_op_params(para_check.REQUIRED_INPUT, para_check.REQUIRED_OUTPUT,
                            para_check.KERNEL_NAME)
def sigmoid(x, y,  kernel_name="sigmoid"):
    """leaky_relu op for input tensor

       f(x)= x(x>=0) or negative_slope*x(x<0) equal to
       f(x)=negative_slope*x

    Parameters
    ----------
    x : TVM tensor
        input tensor has shape and dtype attributes
    y : dict
        dict with keys(shape and dtype) of output

    kernel_name : str
        cce kernel name, default value is "leaky_relu"

    Returns
    ------
    None
    """

    # check input tensor shape
    shape = x.get("shape")
    dtype = x.get("dtype")

    # check input tensor data_type
    check_list = ["float16", "float32"]
    para_check.check_dtype(dtype.lower(), check_list, param_name="x")

    inp_dtype = dtype.lower()
    input_data_x = tvm.placeholder(shape, name="input_data_x", dtype=inp_dtype)

    with tvm.target.cce():

        res = sigmoid_compute(input_data_x, y,  kernel_name)
        sch = tbe.auto_schedule(res)

    config = {"name": kernel_name,
              "tensor_list": [input_data_x, res]}
    tbe.build(sch, config)
    print("=================sigmoid已调用=================")