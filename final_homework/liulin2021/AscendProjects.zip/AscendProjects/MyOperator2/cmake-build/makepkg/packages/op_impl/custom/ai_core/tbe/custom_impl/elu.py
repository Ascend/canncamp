from tbe import dsl
from tbe import tvm
from tbe.common.register import register_op_compute
from tbe.common.utils import para_check
from tbe.common.utils import shape_util


@register_op_compute("elu", op_mode="static", support_fusion=False)
def elu_compute(x, y, kernel_name="elu"):
    """
    To do: Implement the operator by referring to the
           TBE Operator Development Guide.
    """

    print("===self-defined operator elu===")
    input_dtype = x.dtype.lower()
    shape = x.shape
    # print(shape)

    # step 1, prepare '1' and '0'
    const_one = tvm.const(1, input_dtype)
    const_zero = tvm.const(0, input_dtype)
    tensor_one = dsl.broadcast(const_one, shape)
    tensor_zero = dsl.broadcast(const_zero, shape)

    # step 2
    # if x < 0, res = exp(x) - 1
    # if x >= 0, res = x
    exp_x = dsl.vexp(x)
    exp_x_sub_one = dsl.vsub(exp_x, tensor_one)
    res = dsl.vcmpsel(lhs=x, rhs=tensor_zero, operation='lt', slhs=exp_x_sub_one, srhs=x)

    # step 3, adjust data_type
    res = dsl.cast_to(res, input_dtype)
    # print(res.shape)
    return res


@para_check.check_op_params(para_check.REQUIRED_INPUT, para_check.REQUIRED_OUTPUT, para_check.KERNEL_NAME)
def elu(x, y, kernel_name="elu"):
    """
    To do: Implement the operator by referring to the
           TBE Operator Development Guide.
    """
    data_x = tvm.placeholder(x.get("shape"), dtype=x.get("dtype"), name="data_x")

    res = elu_compute(data_x, y, kernel_name)

    # auto schedule
    with tvm.target.cce():
        schedule = dsl.auto_schedule(res)

    # operator build
    config = {"name": kernel_name,
              "tensor_list": [data_x, res]}
    dsl.build(schedule, config)


if __name__ == '__main__':
    # input_x = {'shape': (5, 6, 7), 'dtype': 'float16'}
    # output_y = {'shape': (5, 6, 7), 'dtype': 'float16'}
    input_x = {'shape': (5, 6, 7), 'dtype': 'float16', 'ori_shape': (5, 6, 7), 'format': 'ND', 'ori_format': 'ND'}
    output_y = {'shape': (5, 6, 7), 'dtype': 'float16', 'ori_shape': (5, 6, 7), 'format': 'ND', 'ori_format': 'ND'}
    elu(input_x, output_y)
