#include "elu.h"
namespace ge {

IMPLEMT_COMMON_INFERFUNC(EluInferShape)
{
    TensorDesc tensordesc_output = op.GetOutputDesc("y");

    tensordesc_output.SetShape(op.GetInputDesc("x").GetShape());
    tensordesc_output.SetDataType(op.GetInputDesc("x").GetDataType());
    tensordesc_output.SetFormat(op.GetInputDesc("x").GetFormat());

    (void)op.UpdateOutputDesc("y", tensordesc_output);
    return GRAPH_SUCCESS;
}

IMPLEMT_VERIFIER(Elu, EluVerify)
{
    return GRAPH_SUCCESS;
}

COMMON_INFER_FUNC_REG(Elu, EluInferShape);
VERIFY_FUNC_REG(Elu, EluVerify);

}  // namespace ge
