import tensorflow as tf
from tensorflow_core.examples.tutorials.mnist import input_data
from tensorflow.python.framework import graph_util
from npu_bridge.npu_init import *

# 引入minist数据集
mnist = input_data.read_data_sets('MNIST_data', one_hot=True)
# 每个批次的大小
batch_size = 100
# 计算需要多少批次
n_batch = mnist.train.num_examples // batch_size

output_node_names = "Sigmoid"
output_graph = '/home/ma-user/AscendProjects/MyTraining2/models/resnet.pb'


def config():
    session_config = tf.ConfigProto(
        allow_soft_placement=True,
        log_device_placement=False, )
    custom_op = session_config.graph_options.rewrite_options.custom_optimizers.add()
    custom_op.name = "NpuOptimizer"
    custom_op.parameter_map["use_off_line"].b = True  # True表示在昇腾AI处理器上执行训练
    session_config.graph_options.rewrite_options.remapping = RewriterConfig.OFF  # 必须显式关闭
    session_config.graph_options.rewrite_options.memory_optimization = RewriterConfig.OFF  # 必须显式关闭
    return session_config


class ResNet:
    def __init__(self, X_input, kernel_size, in_filter, out_filters, stride):
        self.X = X_input
        self.X_sortcut = X_input
        self.stride = stride
        f1, f2, f3 = out_filters
        self.conv_1 = tf.Variable(
            tf.truncated_normal(shape=[1, 1, in_filter, f1], stddev=0.1, mean=0, dtype=tf.float32))
        self.conv_b1 = tf.Variable(tf.zeros([f1]))
        self.conv_2 = tf.Variable(
            tf.truncated_normal(shape=[kernel_size, kernel_size, f1, f2], stddev=0.1, mean=0, dtype=tf.float32))
        self.conv_b2 = tf.Variable(tf.zeros([f2]))
        self.conv_3 = tf.Variable(tf.truncated_normal(shape=[1, 1, f2, f3], stddev=0.1, mean=0, dtype=tf.float32))
        self.conv_b3 = tf.Variable(tf.zeros([f3]))
        self.b_conv_fin = tf.Variable(tf.zeros([f3]))

    def ResNetChoice(self, choice):
        if (choice):
            # frist
            y = tf.nn.elu(tf.nn.conv2d(self.X, self.conv_1, strides=[1, 1, 1, 1], padding="SAME") + self.conv_b1)
            # second
            y = tf.nn.elu(tf.nn.conv2d(y, self.conv_2, strides=[1, 1, 1, 1], padding="SAME") + self.conv_b2)
            # third
            y = tf.nn.elu(tf.nn.conv2d(y, self.conv_3, strides=[1, 1, 1, 1], padding="SAME") + self.conv_b3)
            # final steap
            add = tf.add(y, self.X_sortcut)
            add_result = tf.nn.elu(add + self.b_conv_fin)
            return add_result
        else:
            # frist
            y = tf.nn.elu(tf.nn.conv2d(self.X, self.conv_1, strides=[1, self.stride, self.stride, 1],
                                       padding="SAME") + self.conv_b1)
            # second
            y = tf.nn.elu(tf.nn.conv2d(y, self.conv_2, strides=[1, 1, 1, 1], padding="SAME") + self.conv_b2)
            # third
            y = tf.nn.elu(tf.nn.conv2d(y, self.conv_3, strides=[1, 1, 1, 1], padding="SAME") + self.conv_b3)
            # final steap
            add = tf.nn.conv2d(self.X_sortcut, self.conv_3, strides=[1, 1, 1, 1], padding="SAME")
            add = tf.add(y, add)
            add_result = tf.nn.elu(add + self.b_conv_fin)
            return add_result


class Net:
    def __init__(self):
        # 输入x(数据输入为图片的格式)
        self.x = tf.placeholder(tf.float32, [None, 28, 28, 1])
        # 输入y(标签)
        self.y = tf.placeholder(tf.float32, [None, 10])
        # ----------------------------卷积初始化--------------------------------
        # 卷积第一层
        self.conv1_w = tf.Variable(tf.random_normal([3, 3, 1, 16], dtype=tf.float32, stddev=0.1))
        # 卷积第一层偏移
        self.convb1 = tf.Variable(tf.zeros([16]))

        # --------------------------------全连接初始化---------------------------------------
        # 第一层全连接w
        self.W = tf.Variable(tf.random_normal([7 * 7 * 32, 128], dtype=tf.float32, stddev=0.1))
        # 第一层全连接b
        self.B = tf.Variable(tf.zeros([128]))
        # 第二层全连接w
        self.W1 = tf.Variable(tf.random_normal([128, 10], dtype=tf.float32, stddev=0.1))
        # 第二层全连接b
        self.B1 = tf.Variable(tf.zeros([10]))

    def forward(self):
        # ------------------------------卷积层-----------------------------------
        # 卷积第一层实现
        self.conv1 = tf.nn.elu(tf.nn.conv2d(self.x, self.conv1_w, strides=[1, 1, 1, 1], padding="SAME") + self.convb1)
        # 第一层池化
        self.pool1 = tf.nn.max_pool(self.conv1, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding="SAME")
        # 残差部分
        Rt = ResNet(self.pool1, 3, 16, [8, 8, 16], 1)
        x = Rt.ResNetChoice(True)
        Rt1 = ResNet(x, 3, 16, [8, 8, 16], 1)
        x = Rt1.ResNetChoice(True)
        Rt2 = ResNet(x, 3, 16, [8, 8, 16], 1)
        x = Rt2.ResNetChoice(True)
        Rt3 = ResNet(x, 3, 16, [8, 8, 16], 1)
        x = Rt3.ResNetChoice(True)
        URt = ResNet(x, 3, 16, [16, 16, 32], 1)
        x = URt.ResNetChoice(False)

        self.pool2 = tf.nn.max_pool(x, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding="SAME")
        # 均值tf.nn.avg_pool
        # 归一化层tf.nn.batch_normalization
        # 形状处理
        self.flat = tf.reshape(self.pool2, [-1, 7 * 7 * 32])
        # ---------------------------------全链接层-------------------------------------------
        self.y0 = tf.nn.elu(tf.matmul(self.flat, self.W) + self.B)
        self.yo = tf.nn.sigmoid(tf.matmul(self.y0, self.W1) + self.B1)

    def backword(self):
        self.cross_entropy = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=self.yo, labels=self.y))
        self.optimizer = tf.train.AdamOptimizer(0.003).minimize(self.cross_entropy)
        # 结果存放在布尔型列表
        self.correct_prediction = tf.equal(tf.argmax(self.yo, 1), tf.argmax(self.y, 1))  # argmax返回张量中最大的值所在的位置
        # 求准确率
        self.accuracy = tf.reduce_mean(tf.cast(self.correct_prediction, tf.float32))


if __name__ == '__main__':

    net = Net()
    net.forward()
    net.backword()
    saveFile = "/home/ma-user/AscendProjects/MyTraining2/models/resnet"
    saver = tf.train.Saver()
    with tf.Session(config=config()) as sess:
        sess.run(tf.global_variables_initializer())
        for epoch in range(5):
            for batch in range(n_batch):
                batch_xs, batch_ys = mnist.train.next_batch(batch_size)
                batch_cg = batch_xs.reshape([batch_size, 28, 28, 1])
                sess.run(net.optimizer, feed_dict={net.x: batch_cg, net.y: batch_ys})
                pass
            tmp_test = mnist.test.images
            batch_tmp_test = tmp_test.reshape([10000, 28, 28, 1])
            acc = sess.run(net.accuracy, feed_dict={net.x: batch_tmp_test, net.y: mnist.test.labels})
            print("Iter" + str(epoch) + ',Testing Accuracy=' + str(acc))
        saver.save(sess, saveFile)
        output_graph_def = graph_util.convert_variables_to_constants(  # 模型持久化，将变量值固定
            sess=sess,
            input_graph_def=sess.graph_def,  # 等于:sess.graph_def
            output_node_names=output_node_names.split(","))  # 如果有多个输出节点，以逗号隔开

        with tf.gfile.GFile(output_graph, "wb") as f:  # 保存模型
            f.write(output_graph_def.SerializeToString())  # 序列化输出
        print("%d ops in the final graph." % len(output_graph_def.node))  # 得到当前图有几个操作节点
