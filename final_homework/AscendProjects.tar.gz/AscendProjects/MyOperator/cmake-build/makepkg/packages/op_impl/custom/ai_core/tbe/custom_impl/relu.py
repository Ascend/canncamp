import tbe.dsl as tbe
from tbe import tvm
from tbe.common.register import register_op_compute
from tbe.common.utils import para_check
from tbe.common.utils import shape_util


# pylint: disable=locally-disabled,unused-argument,invalid-name
@register_op_compute("Relu", op_mode="static", support_fusion=False)
def relu_compute(x, y,  kernel_name="relu"):
    print("=================当你看到这句话时，说明我这个自定义relu算子被执行了============================")
    """
    compute for caffe_relu_layer_cce
    """
    inp_dtype = x.dtype.lower()
    shape = x.shape

    # The original relu logic remains unchanged.

    if inp_dtype in ("float32", "int32"):
        tensor_zero = tbe.broadcast(tvm.const(0, inp_dtype), shape)
        data_res = tbe.vmax(x, tensor_zero)
    else:
        data_res = tbe.vrelu(x)

    data_res = tbe.cast_to(data_res, inp_dtype)

    return data_res



@para_check.check_op_params(para_check.REQUIRED_INPUT, para_check.REQUIRED_OUTPUT,
                            para_check.KERNEL_NAME)
def relu(x, y,  kernel_name="relu"):
    """leaky_relu op for input tensor

       f(x)= x(x>=0) or negative_slope*x(x<0) equal to
       f(x)=negative_slope*x

    Parameters
    ----------
    x : TVM tensor
        input tensor has shape and dtype attributes
    y : dict
        dict with keys(shape and dtype) of output

    kernel_name : str
        cce kernel name, default value is "leaky_relu"

    Returns
    ------
    None
    """

    # check input tensor shape
    shape = x.get("shape")
    dtype = x.get("dtype")

    # check input tensor data_type
    check_list = ["float16", "float32", "int32", "int8"]
    para_check.check_dtype(dtype.lower(), check_list, param_name="x")

    inp_dtype = dtype.lower()
    input_data_x = tvm.placeholder(shape, name="input_data_x", dtype=inp_dtype)

    with tvm.target.cce():

        res = relu_compute(input_data_x, y,  kernel_name)
        sch = tbe.auto_schedule(res)

    config = {"name": kernel_name,
              "tensor_list": [input_data_x, res]}
    tbe.build(sch, config)