from tbe import dsl
from tbe import tvm
from tbe.common.register import register_op_compute
from tbe.common.utils import para_check


@register_op_compute("rsqrt")
def rsqrt_compute(x, y, kernel_name="rsqrt"):
    print("=================当你看到这句话时，说明我这个自定义rsqrt算子被执行了============================")
    """
    To do: Implement the operator by referring to the
           TBE Operator Development Guide.
    """
    log_val = dsl.vlog(x)
    mul_val = dsl.vmuls(log_val, tvm.const(-0.5, "float32"))
    res = dsl.vexp(mul_val)
    return res


def rsqrt(x, y, kernel_name="rsqrt"):
    """
    To do: Implement the operator by referring to the
           TBE Operator Development Guide.
    """
    shape_x = x.get("shape")
    input_data_type = x.get("dtype").lower()
    check_list = ["float16", "float32"]
    para_check.check_dtype(input_data_type, check_list, param_name="x")
    data_x = tvm.placeholder(shape_x, dtype=input_data_type, name="data_x")
    res = rsqrt_compute(data_x, y, kernel_name)

    # auto schedule
    with tvm.target.cce():
        schedule = dsl.auto_schedule(res)

    # operator build
    config = {"name": kernel_name,
              "tensor_list": [data_x, res]}
    dsl.build(schedule, config)