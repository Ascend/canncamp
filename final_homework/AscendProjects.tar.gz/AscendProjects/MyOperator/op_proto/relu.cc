#include "relu.h"
namespace ge {

IMPLEMT_COMMON_INFERFUNC(ReluInferShape)
{
    auto x_shape = op.GetInputDescByName("x").GetShape().GetDims();
    DataType x_dtype = op.GetInputDescByName("x").GetDataType();
    TensorDesc y_desc = op.GetOutputDescByName("y");
    y_desc.SetShape(ge::Shape(x_shape));
    y_desc.SetDataType(x_dtype);
    (void)op.UpdateOutputDesc("y", y_desc);
    return GRAPH_SUCCESS;
}

IMPLEMT_VERIFIER(Relu, ReluVerify)
{

    return GRAPH_SUCCESS;
}

COMMON_INFER_FUNC_REG(Relu, ReluInferShape);
VERIFY_FUNC_REG(Relu, ReluVerify);

}  // namespace ge
