#include "rsqrt.h"
namespace ge {

IMPLEMT_COMMON_INFERFUNC(RsqrtInferShape)
{
    return GRAPH_SUCCESS;
}

IMPLEMT_VERIFIER(Rsqrt, RsqrtVerify)
{
    return GRAPH_SUCCESS;
}

COMMON_INFER_FUNC_REG(Rsqrt, RsqrtInferShape);
VERIFY_FUNC_REG(Rsqrt, RsqrtVerify);

}  // namespace ge
